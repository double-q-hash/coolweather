package com.example.helloworld

interface Study {

    fun readBooks()

    fun doHomework() {
        println("do homework default implementation.")
    }

}