package com.example.fragmentbestpractice

class News(val title: String, val content: String)