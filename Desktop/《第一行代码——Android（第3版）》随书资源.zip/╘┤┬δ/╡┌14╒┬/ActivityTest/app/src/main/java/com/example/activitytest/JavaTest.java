package com.example.activitytest;

public class JavaTest {

    public void invokeStaticMethod() {
        HelperKt.doSomething();
    }

}
