package com.example.retrofittest

class Data(val id: String, val content: String)