package com.example.networktest

class App(val id: String, val name: String, val version: String)